import cv2
import numpy as np
import matplotlib.pyplot as plt
import time
from threading import Thread

# Task functions for image processing with performance tracking
def resize_image(image, results, time_dict):
    start_time = time.time()
    results['resize'] = cv2.resize(image, (100, 100))
    end_time = time.time()
    time_dict['resize'] = end_time - start_time

def grayscale_image(image, results, time_dict):
    start_time = time.time()
    results['grayscale'] = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    end_time = time.time()
    time_dict['grayscale'] = end_time - start_time

def blur_image(image, results, time_dict):
    start_time = time.time()
    results['blur'] = cv2.GaussianBlur(image, (15, 15), 0)
    end_time = time.time()
    time_dict['blur'] = end_time - start_time

# Function to perform task parallelism, visualize and show performance graph
def task_parallel_image_processing(image_path):
    image = cv2.imread(image_path)
    results = {}
    time_dict = {}

    # Start parallel tasks
    threads = [
        Thread(target=resize_image, args=(image, results, time_dict)),
        Thread(target=grayscale_image, args=(image, results, time_dict)),
        Thread(target=blur_image, args=(image, results, time_dict)),
    ]

    start_time = time.time()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    end_time = time.time()

    # Visualize the tasks being executed
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes[0, 0].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    axes[0, 0].set_title("Original Image")
    axes[0, 0].axis('off')

    axes[0, 1].imshow(cv2.cvtColor(results['resize'], cv2.COLOR_BGR2RGB))
    axes[0, 1].set_title("Resized Image")
    axes[0, 1].axis('off')

    axes[1, 0].imshow(results['grayscale'], cmap='gray')
    axes[1, 0].set_title("Grayscale Image")
    axes[1, 0].axis('off')

    axes[1, 1].imshow(cv2.cvtColor(results['blur'], cv2.COLOR_BGR2RGB))
    axes[1, 1].set_title("Blurred Image")
    axes[1, 1].axis('off')

    plt.suptitle(f"Tasks completed in {end_time - start_time:.2f} seconds")

    # Plotting the performance graph
    tasks = list(time_dict.keys())
    times = list(time_dict.values())
    
    plt.figure(figsize=(8, 6))
    plt.bar(tasks, times, color=['blue', 'green', 'red'])
    plt.title('Task Parallelism: Time Taken by Each Task')
    plt.xlabel('Tasks')
    plt.ylabel('Time (seconds)')
    plt.show()

# Example of task parallelism for image processing
task_parallel_image_processing('image.jpg')
