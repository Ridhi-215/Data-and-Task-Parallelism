from multiprocessing import Process, Manager  # Correct imports
import matplotlib.pyplot as plt
import numpy as np
import time

# Define tasks
def sort_array(arr, task_id, timings):
    start = time.time()
    print(f"Task {task_id}: Sorting array...")
    sorted_arr = np.sort(arr)
    end = time.time()
    print(f"Task {task_id}: Sorting complete.")
    timings[task_id] = end - start

def sum_array(arr, task_id, timings):
    start = time.time()
    print(f"Task {task_id}: Summing array...")
    total = np.sum(arr)
    end = time.time()
    print(f"Task {task_id}: Summing complete. Total = {total}")
    timings[task_id] = end - start

# Visualize task execution
def visualize_task_parallelism(tasks, start_times, durations):
    fig, ax = plt.subplots()
    ax.barh(tasks, durations, left=start_times, color='lightgreen')
    plt.xlabel("Time (s)")
    plt.ylabel("Tasks")
    plt.title("Task Parallelism Execution Timeline")
    plt.show()

if __name__ == "__main__":
    array = np.random.randint(1, 1000, size=5000)
    tasks = ["Sort Array", "Sum Array"]
    start_times = []
    durations = []
    timings = Manager().dict()  # Corrected multiprocessing.Manager()

    processes = []
    for i, task in enumerate([sort_array, sum_array]):
        p = Process(target=task, args=(array, i, timings))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

    # Simulate timing data
    start_time = time.time()
    end_time = start_time + sum(timings.values())
    start_times = [0, timings[0]]
    durations = list(timings.values())

    # Visualize the execution
    visualize_task_parallelism(tasks, start_times, durations)
