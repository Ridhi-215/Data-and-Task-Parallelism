import numpy as np
import threading
import matplotlib.pyplot as plt
import time
from matplotlib.animation import FuncAnimation

# Function to compute a chunk of matrix multiplication (for each row)
def compute_chunk(A, B, C, start_row, end_row, thread_id, timing_dict, delay=0.05):
    start_time = time.time()
    for i in range(start_row, end_row):
        for j in range(B.shape[1]):
            C[i][j] = np.dot(A[i, :], B[:, j])  # Row-by-column multiplication
        time.sleep(delay)  # Simulate a delay to make the execution time measurable
    end_time = time.time()

    # Store the time taken for each thread
    timing_dict[thread_id] = end_time - start_time

# Function to visualize matrix multiplication with virtual representation
def visualize_matrix_multiplication(A, B, num_threads=4):
    assert A.shape[1] == B.shape[0], "Matrix dimensions do not align for multiplication."
    
    C = np.zeros((A.shape[0], B.shape[1]))  # Initialize resulting matrix C
    threads = []
    timing_dict = {}  # Dictionary to store execution time for each thread
    rows_per_thread = A.shape[0] // num_threads

    # Create threads for data parallelism
    for i in range(num_threads):
        start_row = i * rows_per_thread
        end_row = A.shape[0] if i == num_threads - 1 else (i + 1) * rows_per_thread
        thread = threading.Thread(target=compute_chunk, args=(A, B, C, start_row, end_row, i, timing_dict, 0.05))
        threads.append(thread)
        thread.start()

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

    # Set up subplots for matrix and performance visualization
    fig, (ax_matrix, ax_performance) = plt.subplots(1, 2, figsize=(15, 5))

    # Create a function to update the plot during matrix multiplication (row by row)
    def update_plot(frame, A, B, C, ax_matrix, ax_performance, timing_dict):
        ax_matrix.clear()

        # Display Matrix A (left grid)
        ax_matrix.table(cellText=A.round(2), loc='center', cellLoc='center', colWidths=[0.1] * A.shape[1])
        ax_matrix.set_title("Matrix A")

        # Display Matrix B (right grid)
        ax_matrix.table(cellText=B.round(2), loc='center', cellLoc='center', colWidths=[0.1] * B.shape[1])
        ax_matrix.set_title(f"Matrix A & B Multiplication Progress (Row {frame + 1})")

        # Highlight the current row of A being processed
        ax_matrix.add_patch(plt.Rectangle((-0.5, frame - 0.5), A.shape[1], 1, color='red', alpha=0.3))

        # Display Matrix C progressively updated (showing rows updated)
        ax_matrix.table(cellText=C[:frame+1].round(2), loc='center', cellLoc='center', colWidths=[0.1] * C.shape[1])
        ax_matrix.set_title(f"Matrix C (Updated after Row {frame + 1})")

        # Update performance graph: Time taken by each task (row multiplication)
        tasks = list(range(frame+1))  # Show tasks up to the current row
        times = [timing_dict.get(i, 0) for i in range(frame+1)]  # Get times for completed rows
        ax_performance.clear()
        ax_performance.bar(tasks, times, color='blue')
        ax_performance.set_title('Time Taken by Each Row Computation')
        ax_performance.set_xlabel('Row Index')
        ax_performance.set_ylabel('Time (seconds)')
        ax_performance.set_ylim(0, max(times) * 1.1 if times else 1)  # Adjust Y-axis to fit the max time

        return ax_matrix, ax_performance

    # Set up animation to show step-by-step matrix multiplication (row by row)
    ani = FuncAnimation(fig, update_plot, frames=range(A.shape[0]), 
                        fargs=(A, B, C, ax_matrix, ax_performance, timing_dict), 
                        interval=1000, repeat=False)

    plt.show()

    # Show the time taken by each thread after all rows are processed
    print(f"Time taken for each thread:")
    for row_idx, timing in timing_dict.items():
        print(f"Row {row_idx}: {timing:.4f} seconds")

# Example of Matrix Multiplication with Virtual Visualization
A = np.random.rand(4, 4)  # Matrix A (6x4)
B = np.random.rand(4, 4)  # Matrix B (4x5)

visualize_matrix_multiplication(A, B, num_threads=4)
