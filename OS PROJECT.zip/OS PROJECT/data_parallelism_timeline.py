import numpy as np
import threading
from time import time

# Function to compute a chunk of matrix multiplication
def compute_chunk(A, B, C, start_row, end_row):
    for i in range(start_row, end_row):
        for j in range(B.shape[1]):
            C[i][j] = np.dot(A[i, :], B[:, j])

def data_parallel_matrix_multiplication(A, B, num_threads=4):
    assert A.shape[1] == B.shape[0], "Matrix dimensions do not align for multiplication."

    C = np.zeros((A.shape[0], B.shape[1]))
    threads = []
    rows_per_thread = A.shape[0] // num_threads

    start_time = time()
    for i in range(num_threads):
        start_row = i * rows_per_thread
        end_row = A.shape[0] if i == num_threads - 1 else (i + 1) * rows_per_thread
        thread = threading.Thread(target=compute_chunk, args=(A, B, C, start_row, end_row))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()
    end_time = time()

    print(f"Matrix Multiplication completed in {end_time - start_time:.4f} seconds using {num_threads} threads.")
    return C

# Input Matrices
A = np.random.randint(1, 100, size=(500, 500))
B = np.random.randint(1, 100, size=(500, 500))

# Perform Parallel Matrix Multiplication
result = data_parallel_matrix_multiplication(A, B, num_threads=4)
